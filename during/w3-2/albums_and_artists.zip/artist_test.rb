require 'minitest/autorun'
require 'minitest/pride'

require './artist.rb'
require './artists_migration.rb'

ActiveRecord::Base.establish_connection(
  adapter:  'sqlite3',
  database: 'test.sqlite3'
)

ActiveRecord::Migration.verbose = false

class ArtistTest < Minitest::Test
  def setup
    ArtistsMigration.migrate(:up)
  end

  def teardown
    ArtistsMigration.migrate(:down)
  end

  def test_artist_can_be_saved
    Artist.create(name: "Jennifertones")
    assert_equal "Jennifertones", Artist.last.name
    assert_equal 1, Artist.count
  end

  def test_artist_can_be_saved_again
    Artist.create(name: "Jennifertones")
    assert_equal "Jennifertones", Artist.last.name
    assert_equal 1, Artist.count
  end
end
