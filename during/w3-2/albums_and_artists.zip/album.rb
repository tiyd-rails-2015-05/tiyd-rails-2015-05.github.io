require 'active_record'

ActiveRecord::Base.establish_connection(
  adapter:  'sqlite3',
  database: 'db.sqlite3'
)

class Album < ActiveRecord::Base
  belongs_to :artist

  def sell(amount=1)
    self.amount_in_stock = self.amount_in_stock - amount
  end

  def buy(amount=1)
    self.amount_in_stock = self.amount_in_stock + amount
  end

  def discount(percent)
    self.price -= price*percent/100.0
  end
end
