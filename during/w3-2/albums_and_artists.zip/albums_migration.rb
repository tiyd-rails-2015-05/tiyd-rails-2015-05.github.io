require 'active_record'

ActiveRecord::Base.establish_connection(
  adapter:  'sqlite3',
  database: 'db.sqlite3'
)

class AlbumsMigration < ActiveRecord::Migration
  def change
    create_table :albums do |t|
      t.references :artist
      t.string :name
      t.decimal(:price, {precision: 2, scale: 6})
      t.integer :amount_in_stock
      t.timestamps
    end
  end
end
