require "./album.rb"
require "./artist.rb"

thriller = Album.new({name: "Thriller", price: 0.50, amount_in_stock: 300})
rush = Album.new(name: "Rush", price: 5.00, amount_in_stock: 100)

# 300
puts thriller.amount_in_stock

thriller.buy(5)

# 295
puts thriller.amount_in_stock

mj = Artist.create(name: "MJ")

# "MJ"
puts mj.name

mj.assign(thriller)
mj.assign(rush)

# "Thriller, Rush"
p mj.album_names

mj.discount_catalog(50)

thriller.save
rush.save

# 0.25
puts thriller.price
# 2.5
puts rush.price
